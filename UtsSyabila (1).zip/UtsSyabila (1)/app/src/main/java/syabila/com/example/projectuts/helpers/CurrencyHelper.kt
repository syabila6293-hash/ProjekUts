package syabila.com.example.projectuts.helpers

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToLong

object CurrencyHelper {
    // Harga dari API dalam USD (asumsi), dikonversi dengan kurs tetap 1 USD = Rp16.000
    private const val USD_TO_IDR = 16000.0

    // Dibulatkan ke Rp1.000 terdekat supaya tampil seperti harga jual di toko
    private const val ROUND_TO = 1000.0

    fun formatRupiah(usd: Double?): String {
        val idr = (usd ?: 0.0) * USD_TO_IDR
        val rounded = ((idr / ROUND_TO).roundToLong() * ROUND_TO.toLong())
        val nf = NumberFormat.getNumberInstance(Locale.forLanguageTag("id-ID"))
        nf.maximumFractionDigits = 0
        return "Rp" + nf.format(rounded)
    }
}
