package syabila.com.example.projectuts.retrofit

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import syabila.com.example.projectuts.model.Product
import syabila.com.example.projectuts.response.ProductResponse

interface ApiService {

    // GET https://dummyjson.com/products?limit=25&select=id,title,...
    @GET("products")
    fun getProducts(
        @Query("limit") limit: Int,
        @Query("select") select: String
    ): Call<ProductResponse>

    // GET https://dummyjson.com/products/{id}?select=...
    @GET("products/{id}")
    fun getProductDetail(
        @Path("id") id: Int,
        @Query("select") select: String
    ): Call<Product>
}
