package syabila.com.example.projectuts.helpers

object Constants {
    const val BASE_URL = "https://dummyjson.com/"
    const val LIMIT = 25

    // Kolom yang diminta oleh soal (poin 3.c)
    const val SELECT_FIELDS =
        "id,title,description,category,price,stock,availabilityStatus," +
        "tags,dimensions,reviews,rating,images,thumbnail"
}
