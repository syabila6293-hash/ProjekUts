package syabila.com.example.projectuts.response

import syabila.com.example.projectuts.model.Product

data class ProductResponse(
    val products: List<Product>? = null,
    val total: Int? = null,
    val skip: Int? = null,
    val limit: Int? = null
)
