package syabila.com.example.projectuts.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import syabila.com.example.projectuts.R
import syabila.com.example.projectuts.adapter.ProductAdapter
import syabila.com.example.projectuts.databinding.FragmentDashboardBinding
import syabila.com.example.projectuts.helpers.Constants
import syabila.com.example.projectuts.response.ProductResponse
import syabila.com.example.projectuts.retrofit.ApiConfig
import syabila.com.example.projectuts.ui.detail.DetailActivity

class DashboardFragment : Fragment(R.layout.fragment_dashboard) {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ProductAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentDashboardBinding.bind(view)

        adapter = ProductAdapter { product ->
            val intent = Intent(requireContext(), DetailActivity::class.java)
            intent.putExtra(DetailActivity.EXTRA_ID, product.id)
            startActivity(intent)
        }
        binding.rvData.layoutManager = LinearLayoutManager(requireContext())
        binding.rvData.adapter = adapter

        loadProducts()
    }

    private fun loadProducts() {
        binding.progressBar.visibility = View.VISIBLE
        ApiConfig.getApiService()
            .getProducts(Constants.LIMIT, Constants.SELECT_FIELDS)
            .enqueue(object : Callback<ProductResponse> {
                override fun onResponse(call: Call<ProductResponse>, response: Response<ProductResponse>) {
                    if (_binding == null) return
                    binding.progressBar.visibility = View.GONE
                    val list = response.body()?.products
                    if (response.isSuccessful && list != null) {
                        adapter.submitList(list)
                    } else {
                        Toast.makeText(requireContext(), "Gagal memuat data: ${response.code()}", Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<ProductResponse>, t: Throwable) {
                    if (_binding == null) return
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
