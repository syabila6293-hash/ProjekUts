package syabila.com.example.projectuts.model

data class Dimensions(
    val width: Double? = null,
    val height: Double? = null,
    val depth: Double? = null
)

data class Review(
    val rating: Int? = null,
    val comment: String? = null,
    val date: String? = null,
    val reviewerName: String? = null,
    val reviewerEmail: String? = null
)

data class Product(
    val id: Int = 0,
    val title: String? = null,
    val description: String? = null,
    val category: String? = null,
    val price: Double? = null,
    val stock: Int? = null,
    val availabilityStatus: String? = null,
    val tags: List<String>? = null,
    val dimensions: Dimensions? = null,
    val reviews: List<Review>? = null,
    val rating: Double? = null,
    val images: List<String>? = null,
    val thumbnail: String? = null
)
