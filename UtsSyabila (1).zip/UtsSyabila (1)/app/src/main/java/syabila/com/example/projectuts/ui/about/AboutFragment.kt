package syabila.com.example.projectuts.ui.about

import androidx.fragment.app.Fragment
import syabila.com.example.projectuts.R

class AboutFragment : Fragment(R.layout.fragment_about)