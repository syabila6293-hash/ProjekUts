package syabila.com.example.projectuts.ui.detail

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import syabila.com.example.projectuts.adapter.ImageSliderAdapter
import syabila.com.example.projectuts.adapter.ReviewAdapter
import syabila.com.example.projectuts.databinding.ActivityDetailBinding
import syabila.com.example.projectuts.databinding.DialogReviewsBinding
import syabila.com.example.projectuts.databinding.ItemReviewBinding
import syabila.com.example.projectuts.helpers.Constants
import syabila.com.example.projectuts.helpers.CurrencyHelper
import syabila.com.example.projectuts.model.Product
import syabila.com.example.projectuts.model.Review
import syabila.com.example.projectuts.retrofit.ApiConfig
import java.util.Locale

class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "extra_id"
    }

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        binding.toolbar.setNavigationOnClickListener { finish() }

        val id = intent.getIntExtra(EXTRA_ID, -1)
        if (id == -1) {
            Toast.makeText(this, "ID produk tidak valid", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        loadDetail(id)
    }

    private fun loadDetail(id: Int) {
        binding.progressBar.visibility = View.VISIBLE
        ApiConfig.getApiService()
            .getProductDetail(id, Constants.SELECT_FIELDS)
            .enqueue(object : Callback<Product> {
                override fun onResponse(call: Call<Product>, response: Response<Product>) {
                    binding.progressBar.visibility = View.GONE
                    val product = response.body()
                    if (response.isSuccessful && product != null) {
                        showProduct(product)
                    } else {
                        Toast.makeText(this@DetailActivity, "Gagal memuat detail: ${response.code()}", Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<Product>, t: Throwable) {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(this@DetailActivity, "Error: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
    }

    private fun showProduct(p: Product) {
        binding.scrollContent.visibility = View.VISIBLE

        // Gambar dari kolom images
        val images = p.images.orEmpty()
        binding.viewPagerImages.adapter = ImageSliderAdapter(images)

        binding.tvTitle.text = p.title ?: "-"
        binding.tvProductId.text = "ID Produk: ${p.id}"
        binding.tvCategory.text = (p.category ?: "-").replaceFirstChar { it.uppercase() }
        binding.tvPrice.text = CurrencyHelper.formatRupiah(p.price)
        binding.tvRating.text = "★ ${p.rating ?: 0.0}"
        binding.tvStock.text = "Stok: ${p.stock ?: 0}"
        binding.tvAvailability.text = p.availabilityStatus ?: "-"
        binding.tvTags.text = p.tags?.joinToString(", ") ?: "-"

        val d = p.dimensions
        binding.tvDimensions.text = if (d != null) {
            String.format(
                Locale.US, "%.2f x %.2f x %.2f (W x H x D)",
                d.width ?: 0.0, d.height ?: 0.0, d.depth ?: 0.0
            )
        } else "-"

        binding.tvDescription.text = p.description ?: "-"

        showReviews(p.reviews.orEmpty())
    }

    private fun showReviews(reviews: List<Review>) {
        binding.reviewContainer.removeAllViews()

        if (reviews.isEmpty()) {
            binding.tvNoReview.visibility = View.VISIBLE
            binding.tvSeeAllReviews.visibility = View.GONE
            return
        }
        binding.tvNoReview.visibility = View.GONE

        // Default: hanya 1 review teratas
        val itemBinding = ItemReviewBinding.inflate(layoutInflater, binding.reviewContainer, false)
        ReviewAdapter.bind(itemBinding, reviews.first())
        binding.reviewContainer.addView(itemBinding.root)

        // Link "lihat semua review" -> dialog
        if (reviews.size > 1) {
            binding.tvSeeAllReviews.visibility = View.VISIBLE
            binding.tvSeeAllReviews.text = "Lihat semua review (${reviews.size})"
            binding.tvSeeAllReviews.setOnClickListener { showAllReviewsDialog(reviews) }
        } else {
            binding.tvSeeAllReviews.visibility = View.GONE
        }
    }

    private fun showAllReviewsDialog(reviews: List<Review>) {
        val dialogBinding = DialogReviewsBinding.inflate(layoutInflater)
        dialogBinding.rvReviews.layoutManager = LinearLayoutManager(this)
        dialogBinding.rvReviews.adapter = ReviewAdapter(reviews)

        MaterialAlertDialogBuilder(this)
            .setTitle("Semua Review (${reviews.size})")
            .setView(dialogBinding.root)
            .setPositiveButton("Tutup", null)
            .show()
    }
}
