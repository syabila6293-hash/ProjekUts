package syabila.com.example.projectuts.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import syabila.com.example.projectuts.databinding.ItemProductBinding
import syabila.com.example.projectuts.helpers.CurrencyHelper
import syabila.com.example.projectuts.model.Product

class ProductAdapter(
    private val onItemClick: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ViewHolder>() {

    private val items = mutableListOf<Product>()

    @SuppressLint("NotifyDataSetChanged")
    fun submitList(list: List<Product>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    inner class ViewHolder(private val binding: ItemProductBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(product: Product) {
            binding.tvTitle.text = product.title ?: "-"
            binding.tvPrice.text = CurrencyHelper.formatRupiah(product.price)
            binding.tvStock.text = "Stok: ${product.stock ?: 0}"
            binding.tvRating.text = "★ ${product.rating ?: 0.0}"

            Glide.with(binding.root)
                .load(product.thumbnail)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .into(binding.imgThumbnail)

            binding.root.setOnClickListener { onItemClick(product) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(items[position])

    override fun getItemCount(): Int = items.size
}
