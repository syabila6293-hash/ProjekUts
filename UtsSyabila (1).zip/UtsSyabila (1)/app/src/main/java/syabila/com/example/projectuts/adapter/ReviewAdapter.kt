package syabila.com.example.projectuts.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import syabila.com.example.projectuts.databinding.ItemReviewBinding
import syabila.com.example.projectuts.model.Review

class ReviewAdapter(private val reviews: List<Review>) :
    RecyclerView.Adapter<ReviewAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemReviewBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemReviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        bind(holder.binding, reviews[position])
    }

    override fun getItemCount(): Int = reviews.size

    companion object {
        // Dipakai juga oleh halaman detail untuk menampilkan 1 review teratas
        fun bind(binding: ItemReviewBinding, review: Review) {
            binding.tvReviewer.text = review.reviewerName ?: "-"
            binding.tvReviewRating.text = "★ ${review.rating ?: 0}"
            binding.tvComment.text = review.comment ?: ""
            binding.tvDate.text = review.date?.take(10) ?: ""
        }
    }
}
